# 피그마 링크
https://www.figma.com/file/bR7W7Ba0NKwvGdr8mCh0MI/BUCKETLIST?type=design&node-id=0%3A1&mode=design&t=kZ6BRM7wrBk6Iu6x-1

# 텍스트 
```
My Bucket List

Travel all around the world
Learn a new language
Try a profession in a different field
Achieve your ideal weight
Run a marathon
```
